package cn.edu.thssdb.type;

public enum AlignType {
  LEFT,
  RIGHT,
  CENTER
}
