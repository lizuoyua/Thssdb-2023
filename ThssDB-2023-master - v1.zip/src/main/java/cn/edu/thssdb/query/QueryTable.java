package cn.edu.thssdb.query;

import cn.edu.thssdb.schema.Row;

import java.util.Iterator;

public class QueryTable implements Iterator<Row> {

  QueryTable() {
    // TODO
  }

  @Override
  public boolean hasNext() {
    // TODO
    return true;
  }

  @Override
  public Row next() {
    // TODO
    return null;
  }
}
