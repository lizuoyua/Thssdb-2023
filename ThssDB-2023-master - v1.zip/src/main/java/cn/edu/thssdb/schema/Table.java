package cn.edu.thssdb.schema;

import cn.edu.thssdb.exception.*;
import cn.edu.thssdb.index.BPlusTree;
import cn.edu.thssdb.index.BPlusTreeIterator;
import cn.edu.thssdb.utils.Global;
import cn.edu.thssdb.type.ColumnType;
import cn.edu.thssdb.utils.Pair;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Table implements Iterable<Row> {
  public ReentrantReadWriteLock lock;//可重入读写锁
  private String databaseName;
  public String tableName;
  public ArrayList<Column> columns;//列定义表
  public BPlusTree<Entry, Row> index;//B+树索引
  public int primaryIndex;//主键索引

  /**  新增属性*/
  private String folder;

  private  Meta tableMeta;

  private PersistentStorage<Row> persistentStorageData; // 数据持久化

  /** [method] 无metadata构造方法 */
  public Table(String databaseName, String tableName, Column[] columns, int primaryIndex) {
    initData(databaseName, tableName);
    this.lock = new ReentrantReadWriteLock();
    this.columns = new ArrayList<>(Arrays.asList(columns));
    this.primaryIndex = primaryIndex;
    this.index = new BPlusTree<>();
  }

  /** [method] 含metadata构造方法 */
  public Table(String databaseName, String tableName) {
    initData(databaseName, tableName);
    this.lock = new ReentrantReadWriteLock();
    this.columns = new ArrayList<>();
    this.index = new BPlusTree<>();
    recoverMeta();
    recover(deserialize());
  }

  /** [method] 初始化元数据和数据存储相关 */
  private void initData(String databaseName, String tableName) throws CustomIOException {
    this.databaseName = databaseName;
    this.tableName = tableName;
    folder = Paths.get(Global.DATA_ROOT_FOLDER, databaseName, tableName).toString();
    String meta_name = tableName + ".meta";
    String data_name = tableName + ".data";
    this.persistentStorageData = new PersistentStorage<>(folder, data_name);
    this.tableMeta = new Meta(folder, meta_name);
  }

  /** [method] 持久化metadata */
  private void persistMeta() throws CustomIOException {
    ArrayList<String> meta_data = new ArrayList<>();
    meta_data.add(Global.DATABASE_NAME_META + " " + databaseName);
    meta_data.add(Global.TABLE_NAME_META + " " + tableName);
    meta_data.add(Global.PRIMARY_KEY_INDEX_META + " " + primaryIndex);
    for (Column column : columns) {
      meta_data.add(column.toString(' '));
    }
    this.tableMeta.writeToFile(meta_data);
  }

  /** [method] 恢复metadata */
  private void recoverMeta() {
    ArrayList<String[]> meta_data = this.tableMeta.readFromFile();
    try {
      String[] database_name = meta_data.get(0);
      if (!database_name[0].equals(Global.DATABASE_NAME_META)) {
        throw new WrongMetaFormatException();
      }
      if (!this.databaseName.equals(database_name[1])) {
        throw new WrongMetaFormatException();
      }
    } catch (Exception e) {
      throw new WrongMetaFormatException();
    }

    try {
      String[] table_name = meta_data.get(1);
      if (!table_name[0].equals(Global.TABLE_NAME_META)) {
        throw new WrongMetaFormatException();
      }
      if (!this.tableName.equals(table_name[1])) {
        throw new WrongMetaFormatException();
      }
    } catch (Exception e) {
      throw new WrongMetaFormatException();
    }

    try {
      String[] primary_key = meta_data.get(2);
      if (!primary_key[0].equals(Global.PRIMARY_KEY_INDEX_META)) {
        throw new WrongMetaFormatException();
      }
      this.primaryIndex = Integer.parseInt(primary_key[1]);
    } catch (Exception e) {
      throw new WrongMetaFormatException();
    }
    for (int i = 3; i < meta_data.size(); i++) {
      String[] column_info = meta_data.get(i);
      try {
        String name = column_info[0];
        ColumnType type = ColumnType.string2ColumnType(column_info[1]);
        boolean primary = column_info[2].equals("true");
        boolean notNull = column_info[3].equals("true");
        int maxLength = Integer.parseInt(column_info[4]);
        this.columns.add(new Column(name, type, primary, notNull, maxLength));
      } catch (Exception e) {
        throw new WrongMetaFormatException();
      }
    }
  }

  /** [method] 持久化表 */
  public synchronized void persist() {
    serialize();
    persistMeta();
  }

  /** [method] 恢复表 [note] 从持久化数据中恢复表 */
  private synchronized void recover(ArrayList<Row> rows) {
    for (Row row : rows) {
      index.put(row.getEntries().get(primaryIndex), row);
    }
  }

  /** [method] 通过row插入行 */
  public void insert(Row row) {
    index.put(row.getEntries().get(primaryIndex), row);
  }

  /** [method] 通过字符串形式插入行 */
  public void insert(String row) {
    try {
      String[] info = row.split(",");
      ArrayList<Entry> entries = new ArrayList<>();
      int i = 0;
      for (Column c : columns) {
        entries.add(new Entry(ColumnType.getColumnTypeValue(c.getType(), info[i])));
        i++;
      }
      index.put(entries.get(primaryIndex), new Row(entries));
    } catch (Exception e) {
      throw e;
    }
  }

  /** [method] 通过row删除行 */
  public void delete(Row row) {
    index.remove(row.getEntries().get(primaryIndex));
  }

  /** [method] 通过主键的entry删除行 */
  public void delete(Entry entry) {
    index.remove(entry);
  }

  /** [method] 通过主键的值删除行 */
  public void delete(String val) {
    ColumnType c = columns.get(primaryIndex).getType();
    Entry primaryEntry = new Entry(ColumnType.getColumnTypeValue(c, val));
    index.remove(primaryEntry);
  }

  /** [method] 删除所有行 */
  public void delete() {
    index.clear();
    index = new BPlusTree<>();
  }

  /** [method] 更新行 */
  public void update(Row oldRow, Row newRow) {
    if (oldRow.getEntries().get(primaryIndex).compareTo(newRow.getEntries().get(primaryIndex))
            == 0) {
      index.update(newRow.getEntries().get(primaryIndex), newRow);
    } else {
      try {
        delete(oldRow);
        insert(newRow);
      } catch (DuplicateKeyException e) {
        throw e;
      }
    }
  }

  /** [method] 更新行，但不是删+增 */
  public void updateNoRemove(Row oldRow, Row newRow) {
    index.updateNoRemove(oldRow.getEntries().get(primaryIndex), newRow);
  }

  /** [method] 快速更新所有行 */
  public void updateAll(int idx, Comparable val) {
    BPlusTreeIterator<Entry, Row> it = index.iterator();
    while (it.hasNext()) {
      it.next().right.getEntries().set(idx, new Entry(val));
    }
  }

  /** [method] 由Entry查找行 */
  public Row search(Entry entry) {
    return index.get(entry);
  }

  /** [method] 序列化 */
  private void serialize() {
    persistentStorageData.serialize(iterator());
  }

  /** [method] 反序列化 */
  private ArrayList<Row> deserialize() {
    return persistentStorageData.deserialize();
  }

  /** [method] 删除table（包括表本身） */
  public void drop() {
    this.index.clear();
    this.tableMeta.deleteFile();
    this.persistentStorageData.deleteFile();
    new File(this.folder).delete();
  }

  /** [class] 表迭代器（按行） */
  private class TableIterator implements Iterator<Row> {
    private Iterator<Pair<Entry, Row>> iterator;

    TableIterator(Table table) {
      this.iterator = table.index.iterator();
    }

    @Override
    public boolean hasNext() {
      return iterator.hasNext();
    }

    @Override
    public Row next() {
      return iterator.next().right;
    }
  }

  /** [method] 创建迭代器（按行） */
  @Override
  public Iterator<Row> iterator() {
    return new TableIterator(this);
  }
}
